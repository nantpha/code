package com.sjapp.authserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthServerRunner {

	public static void main(String[] args) {
		SpringApplication.run(AuthServerRunner.class, args);
	}
}
