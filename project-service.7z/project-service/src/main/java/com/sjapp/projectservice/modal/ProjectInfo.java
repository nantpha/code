package com.sjapp.projectservice.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class ProjectInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Prj_Seq_Generator")
	@SequenceGenerator(name = "Prj_Seq_Generator", sequenceName = "Project_Sequence")
	private int projectId;

	@Column(nullable = false, length = 50)
	private String projectName;

	@Column(nullable = false, length = 250)
	private String description;

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
