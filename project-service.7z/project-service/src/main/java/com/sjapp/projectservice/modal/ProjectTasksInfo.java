package com.sjapp.projectservice.modal;

import java.util.Collections;
import java.util.List;

public class ProjectTasksInfo {

	private ProjectInfo project;
	private List<TaskInfo> tasks;

	public ProjectInfo getProject() {
		return project;
	}

	public void setProject(ProjectInfo project) {
		this.project = project;
	}

	public List<TaskInfo> getTasks() {
		return tasks == null ? Collections.emptyList() : tasks;
	}

	public void setTasks(List<TaskInfo> tasks) {
		this.tasks = tasks;
	}
}
