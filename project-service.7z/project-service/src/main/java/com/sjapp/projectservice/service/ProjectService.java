package com.sjapp.projectservice.service;

import com.sjapp.projectservice.modal.ProjectTasksInfo;

public interface ProjectService {

	ProjectTasksInfo findProjectInfo(int projectId);
}
