package com.sjapp.projectservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sjapp.projectservice.modal.ProjectInfo;

@Repository
public interface ProjectInfoRepository extends JpaRepository<ProjectInfo, Integer> {

}
