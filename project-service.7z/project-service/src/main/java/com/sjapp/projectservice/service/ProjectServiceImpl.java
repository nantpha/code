package com.sjapp.projectservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sjapp.projectservice.client.TaskInfoClient;
import com.sjapp.projectservice.dao.ProjectInfoRepository;
import com.sjapp.projectservice.modal.ProjectInfo;
import com.sjapp.projectservice.modal.ProjectTasksInfo;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectInfoRepository projInfoRepository;

	@Autowired
	private TaskInfoClient taskInfoClient;

	@Override
	public ProjectTasksInfo findProjectInfo(int projectId) {

		ProjectTasksInfo projectInfo = new ProjectTasksInfo();

		ProjectInfo project = projInfoRepository.findById(projectId)
				.orElseThrow(() -> new RuntimeException("Project information not found:" + projectId));
		projectInfo.setProject(project);
		projectInfo.setTasks(taskInfoClient.findAllTasks(projectId));

		return projectInfo;
	}
}
