package com.sjapp.projectservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sjapp.projectservice.modal.ProjectTasksInfo;
import com.sjapp.projectservice.service.ProjectService;

@RestController
@RequestMapping("/projects")
public class ProjectController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectController.class);

	@Autowired
	private ProjectService projectService;

	@GetMapping("/{projectId}")
	public ProjectTasksInfo projectInfo(@PathVariable int projectId) {

		LOGGER.info("Retreving project info for: {}", projectId);

		return projectService.findProjectInfo(projectId);
	}

	@GetMapping("/info")
	public String serviceInfo() {
		return "Project service micro-service";
	}
}