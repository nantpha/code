package com.sjapp.projectservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sjapp.projectservice.modal.TaskInfo;

@FeignClient(name = "task-ws")
public interface TaskInfoClient {

	@GetMapping("/tasks/{projectId}")
	List<TaskInfo> findAllTasks(@PathVariable(name = "projectId") int projectId);
}
