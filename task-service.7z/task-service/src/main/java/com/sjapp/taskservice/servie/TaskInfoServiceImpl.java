package com.sjapp.taskservice.servie;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sjapp.taskservice.dao.TaskInfoRepository;
import com.sjapp.taskservice.model.TaskInfo;

@Service
public class TaskInfoServiceImpl implements TaskInfoService {

	@Autowired
	private TaskInfoRepository taskInRepository;

	@Override
	public List<TaskInfo> findAllTasks(int projectId) {
		return taskInRepository.findByProjectId(projectId);
	}
}
