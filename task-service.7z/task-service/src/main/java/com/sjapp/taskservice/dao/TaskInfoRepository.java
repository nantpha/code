package com.sjapp.taskservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sjapp.taskservice.model.TaskInfo;

@Repository
public interface TaskInfoRepository extends JpaRepository<TaskInfo, Integer> {

	List<TaskInfo> findByProjectId(int projectId);
}
