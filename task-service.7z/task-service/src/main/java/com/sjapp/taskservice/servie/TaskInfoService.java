package com.sjapp.taskservice.servie;

import java.util.List;

import com.sjapp.taskservice.model.TaskInfo;

public interface TaskInfoService {

	List<TaskInfo> findAllTasks(int projectId);
}
