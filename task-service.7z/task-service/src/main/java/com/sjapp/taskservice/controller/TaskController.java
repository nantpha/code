package com.sjapp.taskservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sjapp.taskservice.model.TaskInfo;
import com.sjapp.taskservice.servie.TaskInfoService;

@RestController
@RequestMapping("/tasks")
public class TaskController {

	@Autowired
	private TaskInfoService taskInfoService;

	@GetMapping("/{projectId}")
	public List<TaskInfo> findAllTasks(@PathVariable int projectId) {
		return taskInfoService.findAllTasks(projectId);
	}

	@GetMapping("/info")
	public String serviceInfo() {
		return "Task service micro-service";
	}
}
