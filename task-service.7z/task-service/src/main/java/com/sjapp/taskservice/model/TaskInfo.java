package com.sjapp.taskservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class TaskInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Task_Info_Seq_Gen")
	@SequenceGenerator(name = "Task_Info_Seq_Gen", sequenceName = "Task_Info_Sequence")
	private int taskId;

	@Column(nullable = false)
	private int projectId;

	@Column(name = "taskname", nullable = false)
	private String taskName;

	@Column(name = "description", length = 255)
	private String description;

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
